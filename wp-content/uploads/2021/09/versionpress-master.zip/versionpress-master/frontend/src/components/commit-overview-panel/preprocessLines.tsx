/// <reference path='../common/Commits.d.ts' />
/// <reference path='./CommitOverviewPanel.d.ts' />

import * as ArrayUtils from '../../utils/ArrayUtils';

const preprocessLines = (changes: Change[]): PreprocessedLine[] => {
  const changesByTypeAndAction = ArrayUtils.groupBy(changes, change => [change.type, change.action]) as ChangesByTypeAndAction;
  let preprocessedLines: PreprocessedLine[] = [];

  for (const type in changesByTypeAndAction) {
    for (const action in changesByTypeAndAction[type]) {
      const changes = changesByTypeAndAction[type][action];
      const lines = preprocessLinesByTypeAndAction(changes, type, action);
      preprocessedLines = preprocessedLines.concat(lines);
    }
  }

  return preprocessedLines;
};

const groupByTag = (changes: Change[], tag: string): PreprocessedLine[] => {
  const metaByTag = ArrayUtils.groupBy(changes, c => c.tags[tag]) as { [key: string]: Change[] };
  return Object.keys(metaByTag).map(tagValue => {
    const { type, action } = changes[0];
    return {
      key: type + '-' + action + '-' + tagValue,
      changes: metaByTag[tagValue],
    };
  });
};

function preprocessLinesByTypeAndAction(changes: Change[], type: string, action: string): PreprocessedLine[] {
  if (type === 'usermeta') {
    return groupByTag(changes, 'VP-User-Login');
  }
  if (type === 'postmeta') {
    return groupByTag(changes, 'VP-Post-Title');
  }
  if (type === 'versionpress' && (action === 'undo' || action === 'rollback')) {
    return changes.map((change, i) => ({
      key: type + '-' + action + '-' + i,
      changes: [change],
    }));
  }
  if (type === 'comment') {
    return groupByTag(changes, 'VP-Comment-PostTitle');
  }
  if (type === 'post') {
    return groupByTag(changes, 'VP-Post-Type');
  }
  return [{
    key: type + '-' + action,
    changes,
  }];
}

export default preprocessLines;
